import { Component, OnInit } from '@angular/core';
import { Note } from './note';
import { NotesService } from './notes.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  errMessage: string;
  note = new Note();
  notesArray:Note[];
  panelOpenState = false;
  constructor(private noteService: NotesService) { }
  ngOnInit() {
   this.viewNotes();
  }
  viewNotes(){
    this.noteService.getNotes().subscribe(
      notes => this.notesArray = notes,
      err => this.errMessage = err.message);
  }
  addNotes() {
    if (!this.note.title && !this.note.text) { 
      this.errMessage = 'Title and Text both are required fields';
    }
    else if(!this.note.title){
      this.errMessage='Title is required field';
    }
    else{
      this.notesArray.push(this.note);
      this.noteService.addNote(this.note).subscribe(
        data => {this.errMessage=''; },
        err => {
          const index=this.notesArray.findIndex(note => note.title === this.note.title);
          this.notesArray.splice(index, 1); 
          this.errMessage = err.message;
        }); 
    }
    this.note.text='';
    this.note.title='';
  }
}
