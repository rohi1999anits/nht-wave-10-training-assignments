import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit{
  errMessage: string;
  note = new Note();
  notes:Note[];
  panelOpenState = false;
  constructor(private noteService: NotesService) { }
  ngOnInit() {
   this.viewNotes();
  }
  viewNotes(){
    this.noteService.getNotes().subscribe(
      notes => this.notes = notes,
      err => this.errMessage = err.message);
  }
  addNotes() {
    if (!this.note.title && !this.note.text) { 
      this.errMessage = 'Title and Text both are required fields';
    }
    else{
      this.noteService.addNote(this.note).subscribe(
        data =>  {
         this.notes.push(data);
         // console.log(this.notes);
          this.errMessage=''; },
        err => {
          const index=this.notes.findIndex(note => note.title === this.note.title);
          this.notes.splice(index, 1); 
          this.errMessage = err.message;
        }); 
    }
    this.note.title='';
    this.note.text='';
  }
}
