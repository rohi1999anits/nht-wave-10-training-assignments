import { AuthenticationService } from '../services/authentication.service';
import { Component } from '@angular/core';
import { FormControl ,Validators} from '@angular/forms';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = new FormControl('',Validators.required);
  password = new FormControl('',Validators.required);
  bearerToken:any;
  submitMessage='';
  user:any;
    constructor(private authService:AuthenticationService,private routeService:RouterService){}

    loginSubmit() {
      const user={username:this.username.value,
                  password:this.password.value 
                  };
      if(this.username.hasError('required') || this.password.hasError('required')){
           this.submitMessage='Username and Password required';
      }else{
      this.authService.authenticateUser(user).subscribe(
      response=>{this.authService.setBearerToken(response['token']);
      this.routeService.routeToDashboard();
      this.submitMessage='';
                }, error=>{
                      if(error.status===404){
                           this.submitMessage=error.message;
                      }
                      else{
                           this.submitMessage=error.error.message;
                      }
                      }
      );
     }
   }
}
