package com.stackroute.datamunger;


//import java.util.Scanner;


public class DataMunger {

	/*
	 * There are total 5 DataMungertest files:
	 * 
	 * 1)DataMungerTestTask1.java file is for testing following 3 methods
	 * a)getSplitStrings() b) getFileName() c) getBaseQuery()
	 * 
	 * Once you implement the above 3 methods,run DataMungerTestTask1.java
	 * 
	 * 2)DataMungerTestTask2.java file is for testing following 3 methods
	 * a)getFields() b) getConditionsPartQuery() c) getConditions()
	 * 
	 * Once you implement the above 3 methods,run DataMungerTestTask2.java
	 * 
	 * 3)DataMungerTestTask3.java file is for testing following 2 methods
	 * a)getLogicalOperators() b) getOrderByFields()
	 * 
	 * Once you implement the above 2 methods,run DataMungerTestTask3.java
	 * 
	 * 4)DataMungerTestTask4.java file is for testing following 2 methods
	 * a)getGroupByFields() b) getAggregateFunctions()
	 * 
	 * Once you implement the above 2 methods,run DataMungerTestTask4.java
	 * 
	 * Once you implement all the methods run DataMungerTest.java.This test case
	 * consist of all the test cases together.
	 */

	/*
	 * This method will split the query string based on space into an array of words
	 * and display it on console
	 */
	  public String[] getSplitStrings(String queryString) { 
			String[] words=queryString.toLowerCase().split(" ");
			return words;
	        }
	 
	/*
	 * Extract the name of the file from the query. File name can be found after a
	 * space after "from" clause. Note: ----- CSV file can contain a field that
	 * contains from as a part of the column name. For eg: from_date,from_hrs etc.
	 * 
	 * Please consider this while extracting the file name in this method.
	 */

	
	  public String getFileName(String queryString) { String[]
	  words=queryString.split(" "); String s=null; for(int i=0;i<words.length;i++)
	  { if(words[i].equalsIgnoreCase("from")) { s=words[i+1]; break; } }
	  
	  return s; }
//	 
	  
	/*
	 * This method is used to extract the baseQuery from the query string. BaseQuery
	 * contains from the beginning of the query till the where clause
	 * 
	 * Note: ------- 1. The query might not contain where clause but contain order
	 * by or group by clause 2. The query might not contain where, order by or group
	 * by clause 3. The query might not contain where, but can contain both group by
	 * and order by clause
	 * 
	 */
	
	  public String getBaseQuery(String queryString) { 
		  String[] words=queryString.split(" "); 
		  //String[] one=new String[1];
		  String s=null;
		  if(!queryString.contains("where") && !queryString.contains(" order by") && !queryString.contains(" group by")) {
			  return queryString;
			  }
		  String[] s1;int c=0;
		  for(int i=0;i<words.length;i++)
		  { if(words[i].equalsIgnoreCase("where") || words[i].equalsIgnoreCase("group") ||  words[i].equalsIgnoreCase("order") ) { 
			  System.out.println("hi");
			  break; 
			  }
		  c++;
		   } 
		  s1=new String[c];
		  for(int i=0;i<words.length;i++)
	  { if(words[i].equalsIgnoreCase("where") || words[i].equalsIgnoreCase("group") || words[i].equalsIgnoreCase("order")) { 
		  s=String.join(" ",s1);
		  break; }
	  s1[i]=words[i];
	   } 
		  return s; }
		  

	 
	 /*
	  
	  This method will extract the fields to be selected from the query string. The
	  query string can have multiple fields separated by comma. The extracted
	  fields will be stored in a String array which is to be printed in console as
	  well as to be returned by the method
	  
	  Note: 1. The field name or value in the condition can contain keywords as a
	  substring. For eg: from_city,job_order_no,group_no etc. 2. The field name can
	  contain '*'
	 */ 
	  
	
	  public String[] getFields(String queryString) { 
		  String[] words=queryString.split(" ");
		  String[] s=words[1].split(","); 
	  return s; 
	  }
	  
	  /*
	  This method is used to extract the conditions part from the query string. The
	  conditions part contains starting from where keyword till the next keyword,
	  which is either group by or order by clause. In case of absence of both group
	  by and order by clause, it will contain till the end of the query string.
	  Note: 1. The field name or value in the condition can contain keywords as a
	  substring. For eg: from_city,job_order_no,group_no etc. 2. The query might
	  not contain where clause at all.
	  */
	  
     public String getConditionsPartQuery(String queryString) {
    	 if(!queryString.contains("where "))
    		 return null;
	  String[] words=queryString.toLowerCase().split("where "); 
	 String[] s=new String [2]; 
	  String st=null;  
    if(words[1].contains("group by"))
		 st="group by";
    else if(words[1].contains("order by"))
    	 st="order by";
    else
    	return words[1];
    s=words[1].split(st);
    return s[0].trim();
	  }
//	  
//	  
//	 /* This method will extract condition(s) from the query string. The query can
//	  contain one or multiple conditions. In case of multiple conditions, the
//	  conditions will be separated by AND/OR keywords. for eg: Input: select
//	  city,winner,player_match from ipl.csv where season > 2014 and city
//	  ='Bangalore'
//	  
//	  This method will return a string array ["season > 2014","city ='bangalore'"]
//	  and print the array
//	  
//	  Note: ----- 1. The field name or value in the condition can contain keywords
//	  as a substring. For eg: from_city,job_order_no,group_no etc. 2. The query
//	  might not contain where clause at all.
//	  */
////	  
    public String[] getConditions(String queryString) { 
    	if(!queryString.contains("where"))
    		return null;
		  String str=queryString.toLowerCase();
		  String[] s=null;
		  if(str.contains("where")){
		  		if(str.contains("where") || str.contains("group by") || str.contains("order by")){
		  		 s=str.split("where")[1].trim().split("group by | order by")[0].trim().split(" and | or ");		
	  		}}
		  for(int i=0;i<s.length;i++) {
			  s[i]=s[i].trim();
			  System.out.println(s[i]);
		  }
		  		 return s;
		  		 }
//	  
//	  
//	 /* This method will extract logical operators(AND/OR) from the query string. The
//	  extracted logical operators will be stored in a String array which will be
//	  returned by the method and the same will be printed Note: 1. AND/OR keyword
//	  will exist in the query only if where conditions exists and it contains
//	  multiple conditions. 2. AND/OR can exist as a substring in the conditions as
//	  well. For eg: name='Alexander',color='Red' etc. Please consider these as well
//	  when extracting the logical operators.
//	  
//	  */
//	  
	  public String[] getLogicalOperators(String queryString) { 
		  String[] words=queryString.toLowerCase().split(" "); 
		  String[] str;
		  int c=0;
		  if(queryString.contains(" and")) {
			  c++;
		  }
		  if(queryString.contains(" or ")) {
			  c++;
		  }
		  if(queryString.contains(" not")) {
			  c++;
		  }
		  if(c==0) {
			  return null;
		  }
		  str=new String[c];
		  c=0;
		  for(String s:words) {
			  if(s.equalsIgnoreCase("and")) {
				  str[c]="and";c++;
			  }
			  if(s.equalsIgnoreCase("or")) {
				  str[c]="or";c++  ;}
			  if(s.equalsIgnoreCase("not")) {
				  str[c]="not";}
		  }
		  for(int i=0;i<str.length;i++) {
			  str[i]=str[i].trim();
		  }
		  return str;
	  }
//	  
//	  
//	 /* This method extracts the order by fields from the query string. Note: 1. The
//	  query string can contain more than one order by fields. 2. The query string
//	  might not contain order by clause at all. 3. The field names,condition values
//	  might contain "order" as a substring. For eg:order_number,job_order Consider
//	  this while extracting the order by fields
//	  */
//	  
//		
		  public String[] getOrderByFields(String queryString) { 
			  if(!queryString.contains("order by "))
				  return null;
			  String[] words=queryString.toLowerCase().split("order by "); 
		  int c=0;
		  String[] w=new String[1];
		  String[] word=new String[2];
		  word[0]=words[1];
		  if(!words[1].contains(",")) {
			  if(words[1].toLowerCase().contains("asc") || words[1].toLowerCase().contains("desc")) { 
				  word=words[1].split(" ");
        		  w[0]=word[0];
			  }
			  else 
        		  w[0]=words[1];
  		  return w;
		  }
		String[] str=words[1].split(","); 
		  for(int i=0;i<str.length;i++) { 
			  if(str[i].toLowerCase().contains("asc") || str[i].toLowerCase().contains("desc")) { 
				  c++;
			  }
		  }
		  String[] s;
			  String[] s1=new String[c]; c=0;
			  for(int i=0;i<str.length;i++) { 
				  s =new String[2];
				  if(str[i].toLowerCase().contains("asc") || str[i].toLowerCase().contains("dsc")) { 
					  s=str[i].split(" ");
					  s1[c]=s[0];
					  c++;
				  }
			  }
			  
		   return s1; 
		  }
////		  
//		 
//	/*  This method extracts the group by fields from the query string. Note: 1. The
//	  query string can contain more than one group by fields. 2. The query string
//	  might not contain group by clause at all. 3. The field names,condition values
//	  might contain "group" as a substring. For eg: newsgroup_name
//	  
//	  Consider this while extracting the group by fields*/
//	  
//  
	  public String[] getGroupByFields(String queryString) {
		  if(!queryString.contains("group by"))
			  return null;
	  String[] words=queryString.toLowerCase().split("group by "); 
	  String[] s=new String[1]; 
	  if(!words[1].contains("order by")) {
		  if(!words[1].contains(",")) {
			  s[0]=words[1];
			  return s;
		  }
		  String[] str=words[1].split(",");
		  return str;
	  }
	 String[] st=words[1].split("order by");
	 if(!st[0].contains(",")) {
		  s[0]=st[0];
		  return s;
	  }
	  String[] str=st[0].split(",");
	  return str;
	  }
	  
	/*  This method extracts the aggregate functions from the query string. Note: 1.
	  aggregate functions will start with "sum"/"count"/"min"/"max"/"avg" followed
	  by "(" 2. The field names might contain"sum"/"count"/"min"/"max"/"avg" as a
	  substring. For eg: account_number,consumed_qty,nominee_name
	  
	  Consider this while extracting the aggregate functions
	  */
	
	  public String[] getAggregateFunctions(String queryString) { 
		  if(!queryString.contains("avg(") && !queryString.contains("max(") && !queryString.contains("min(") && !queryString.contains("count(") && !queryString.contains("sum(") )
			  return null;
		  String[] words=queryString.toLowerCase().split("select "); 
		   String[] str=new String[2];
		   String[] s;
		   String[] p=new String[1];
////		   for(int i=0;i<words.length;i++){
////	  if(i%2==0) {
////		  if(words[i].matches("^avg|min|max|count|sum")) {
////			  str=words[1].split("from");
////	  }
////		   }
	  	   str=words[1].split("from");
		  
	  
	  if(str[0].contains(",")) {
		  s=str[0].split(","); 
		  for(int i=0;i<s.length;i++) {
			  s[i]=s[i].trim();
		  }
		  return s;
	  }
	  else 
		  p[0]=str[0].trim(); 
	  return p;
	
	  }
	 
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		String s = sc.nextLine();sc.close();
//		// sc.next();
//		DataMunger d = new DataMunger();
//		  String[] st = d.getSplitStrings(s); 
//		  for (String i : st) {
//		  System.out.println(i); }
//		 		 
//		System.out.println(d.getFileName(s));
//       System.out.println(d.getBaseQuery(s)); 
//		  String[] s1 =d.getFields(s);
//		  for (String i : s1) {
//		  System.out.println(i); 
//		  }
//		
//		//System.out.println(d.getConditionsPartQuery(s));
//		 String[] s6 =d.getConditions(s);
//		 for (String i : s6) {
//			  System.out.println(i); 
//			  }
//		String[] s2=  d.getLogicalOperators(s); 
//		 for (String i : s2) {
//			  System.out.println(i); 
//			  }
//		
//		String[] s3=  d.getOrderByFields(s);
//		 for (String i : s3) {
//			  System.out.println(i); 
//			  }
//		String[] s4=d.getGroupByFields(s); 
//		 for (String i : s4) {
//		  System.out.println(i); 
//			  }
//		String[] s5=d.getAggregateFunctions(s);
//		 for (String i : s5) {
//			  System.out.println(i); 
//				  }
//							 
//		 }
}