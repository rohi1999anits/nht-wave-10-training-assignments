package com.stackroute.datamunger.query.parser;


import java.util.List;

/* 
 * This class will contain the elements of the parsed Query String such as conditions,
 * logical operators,aggregate functions, file name, fields group by fields, order by
 * fields, Query Type
 * */
public class QueryParameter {
	private String file;
	private String queryString;
	private String baseQuery;
	private String QUERY_TYPE;
	private List<String> fields;
	private List<String> logicalOperators;
	private List<String> orderbyFields;
	private List<String> groupbyFields;
	private List<AggregateFunction> aggregateFunction;
	private List<Restriction> restrictions;
	public String getFileName() {
		return file;
	}
	public void setFileName(String filename) {
		this.file = filename;
	}
	public String getQueryString() {
		return queryString;
	}
	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}
	public String getBaseQuery() {
		return baseQuery;
	}
	public void setBaseQuery(String baseQuery) {
		this.baseQuery = baseQuery;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}
	public List<String> getLogicalOperators() {
		return logicalOperators;
	}
	public void setLogicalOperators(List<String> logicalOperators) {
		this.logicalOperators = logicalOperators;
	}
	public List<String> getOrderByFields() {
		return orderbyFields;
	}
	public void setOrderByFields(List<String> orderbyFields) {
		this.orderbyFields = orderbyFields;
	}
	public List<String> getGroupByFields() {
		return groupbyFields;
	}
	public void setGroupByFields(List<String> groupbyFields) {
		this.groupbyFields = groupbyFields;
	}
	public List<AggregateFunction> getAggregateFunctions() {
		return aggregateFunction;
	}
	public void setAggregateFunctions(List<AggregateFunction> aggregateFunction) {
		this.aggregateFunction = aggregateFunction;
	}
	public List<Restriction> getRestrictions() {
		return restrictions;
	}
	public void setRestrictions(List<Restriction> restrictions) {
		this.restrictions = restrictions;
	}
	
		public String getQUERY_TYPE() {
			return QUERY_TYPE;
		}
		public void setQUERY_TYPE(String qUERY_TYPE) {
			QUERY_TYPE = qUERY_TYPE;
		}
	
}  