### Problem Statement

Consider step 3, Now try to implement the `getColumnType` method using `regex` and look for the following patterns 