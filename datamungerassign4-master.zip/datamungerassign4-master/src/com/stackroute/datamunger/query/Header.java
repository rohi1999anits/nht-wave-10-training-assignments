package com.stackroute.datamunger.query;

import java.util.Arrays;

public class Header {

	/*
	 * This class should contain a member variable which is a String array, to hold
	 * the headers and should override toString() method as well.
	 */
public String[] header;
               
	
	/*
	 * This class should contain a member variable which is a String array, to hold
	 * the headers.
	 */
	 //getter method
	   public Header(String[] header) {
			this.header = header;
		}
	public String[] getHeaders() {
		return header;
	}
     //setter method
	public void setHeaders(String[] header) {
		this.header = header;
	}
	@Override
	public String toString() {
		return "Header [header=" + Arrays.toString(header) + "]";
	}

}
