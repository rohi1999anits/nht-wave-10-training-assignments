package com.stackroute.datamunger.query;

import java.text.SimpleDateFormat;
import java.util.Date;

//This class contains methods to evaluate expressions
public class Filter {
	
	/* 
	 * The evaluateExpression() method of this class is responsible for evaluating 
	 * the expressions mentioned in the query. It has to be noted that the process 
	 * of evaluating expressions will be different for different data types. there 
	 * are 6 operators that can exist within a query i.e. >=,<=,<,>,!=,= This method 
	 * should be able to evaluate all of them. 
	 * Note: while evaluating string expressions, please handle uppercase and lowercase 
	 * 
	 */
	
	public boolean evaluateExpression(String operator,String firstInput,String secondInput,String dataType) throws Exception {
		boolean val=false;
		switch(dataType) {
		case "java.lang.Integer":switch(operator) {
		                            case "=": val=equalTo(firstInput,secondInput,dataType);break;
		                            case "!=":val=notEqualTo(firstInput,secondInput,dataType);break;
		                            case ">":val=greaterThan(firstInput,secondInput,dataType);break;
		                            case ">=":val=greaterThanOrEqualTo(firstInput,secondInput,dataType);break;
		                            case "<":val=lessThan(firstInput,secondInput,dataType);break;
		                            case "<=":val=lessThanOrEqualTo(firstInput,secondInput,dataType);break;
		}
		case "java.lang.Double":switch(operator) {
                                case "=": val=equalTo(firstInput,secondInput,dataType);break;
                                case "!=":val=notEqualTo(firstInput,secondInput,dataType);break;
                                case ">":val=greaterThan(firstInput,secondInput,dataType);break;
                                case ">=":val=greaterThanOrEqualTo(firstInput,secondInput,dataType);break;
                                case "<":val=lessThan(firstInput,secondInput,dataType);break;
                                case "<=":val=lessThanOrEqualTo(firstInput,secondInput,dataType);break;
		}
		case "java.util.Date":switch(operator) {
		                        case "=": val=equalTo(firstInput,secondInput,dataType);break;
                                case "!=":val=notEqualTo(firstInput,secondInput,dataType);break;
                                case ">":val=greaterThan(firstInput,secondInput,dataType);break;
                                case ">=":val=greaterThanOrEqualTo(firstInput,secondInput,dataType);break;
                                case "<":val=lessThan(firstInput,secondInput,dataType);break;
                                case "<=":val=lessThanOrEqualTo(firstInput,secondInput,dataType);break;
		}
		default:
			switch(operator) {
            case "=": if(firstInput.equals(secondInput))
            	          return true;
                      else
                    	  return false;
            case "!=":if(!firstInput.equals(secondInput))
            	           return true;
                      else
                    	  return false;
			}
		}
	
	return val;
	}
	//String =,!= integer all 
	//Method containing implementation of equalTo operator
    public boolean equalTo(String firstInput,String secondInput, String dataType) throws Exception {
    	if(dataType.equals("java.lang.Integer")) {
    		Integer firstInput1=Integer.parseInt(firstInput);
        	Integer secondInput1=Integer.parseInt(secondInput);
    	if(firstInput1 == secondInput1)
    		return true;
    	return false;
    	}
    	else if(dataType.equals("java.lang.Double")) {
    		Double firstInput1=Double.parseDouble(firstInput);
        	Double secondInput1=Double.parseDouble(secondInput);
        	if(firstInput1 == secondInput1)
        		return true;
        	return false;
    	}
    	else {
    		 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-mm-dd");  
 		    SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-mm-dd");
 		    Date date1=formatter1.parse(firstInput);  
 		    Date date2=formatter2.parse(secondInput);  
 		    if(date1.compareTo(date2) == 0) {
 		    	return true;
 		    }
 		    return false;
    	}
    	
    }
	
	//Method containing implementation of notEqualTo operator
	
    public boolean notEqualTo(String firstInput,String secondInput, String dataType) throws Exception {
    	if(dataType.equals("java.lang.Integer")) {
    		Integer firstInput1=Integer.parseInt(firstInput);
        	Integer secondInput1=Integer.parseInt(secondInput);
    	if(firstInput1 != secondInput1)
    		return true;
    	return false;
    	}
    	else if(dataType.equals("java.lang.Double")) {
    		Double firstInput1=Double.parseDouble(firstInput);
        	Double secondInput1=Double.parseDouble(secondInput);
        	if(firstInput1 != secondInput1)
        		return true;
        	return false;
    	}
    	else {
    		 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-mm-dd");  
 		    SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-mm-dd");
 		    Date date1=formatter1.parse(firstInput);  
 		    Date date2=formatter2.parse(secondInput);  
 		    if(date1.compareTo(date2) != 0) {
 		    	return true;
 		    }
 		    return false;
    	}
    	
    }
	
	
	//Method containing implementation of greaterThan operator
	
    public boolean greaterThan(String firstInput,String secondInput, String dataType) throws Exception {
    	if(dataType.equals("java.lang.Integer")) {
    		Integer firstInput1=Integer.parseInt(firstInput);
        	Integer secondInput1=Integer.parseInt(secondInput);
    	if(firstInput1 > secondInput1)
    		return true;
    	return false;
    	}
    	else if(dataType.equals("java.lang.Double")) {
    		Double firstInput1=Double.parseDouble(firstInput);
        	Double secondInput1=Double.parseDouble(secondInput);
        	if(firstInput1 > secondInput1)
        		return true;
        	return false;
    	}
    	else {
    		 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-mm-dd");  
 		    SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-mm-dd");
 		    Date date1=formatter1.parse(firstInput);  
 		    Date date2=formatter2.parse(secondInput);  
 		    if(date1.compareTo(date2) > 0) {
 		    	return true;
 		    }
 		    return false;
    	}
    	
    }
	//Method containing implementation of greaterThanOrEqualTo operator
    public boolean greaterThanOrEqualTo(String firstInput,String secondInput, String dataType) throws Exception {
    	if(dataType.equals("java.lang.Integer")) {
    		Integer firstInput1=Integer.parseInt(firstInput);
        	Integer secondInput1=Integer.parseInt(secondInput);
    	if(firstInput1 >= secondInput1)
    		return true;
    	return false;
    	}
    	else if(dataType.equals("java.lang.Double")) {
    		Double firstInput1=Double.parseDouble(firstInput);
        	Double secondInput1=Double.parseDouble(secondInput);
        	if(firstInput1 >= secondInput1)
        		return true;
        	return false;
    	}
    	else {
    		 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-mm-dd");  
 		    SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-mm-dd");
 		    Date date1=formatter1.parse(firstInput);  
 		    Date date2=formatter2.parse(secondInput);  
 		    if(date1.compareTo(date2) >= 0) {
 		    	return true;
 		    }
 		    return false;
    	}
    	
    }

	//Method containing implementation of lessThan operator
    public boolean lessThan(String firstInput,String secondInput, String dataType) throws Exception {
    	if(dataType.equals("java.lang.Integer")) {
    		Integer firstInput1=Integer.parseInt(firstInput);
        	Integer secondInput1=Integer.parseInt(secondInput);
    	if(firstInput1 < secondInput1)
    		return true;
    	return false;
    	}
    	else if(dataType.equals("java.lang.Double")) {
    		Double firstInput1=Double.parseDouble(firstInput);
        	Double secondInput1=Double.parseDouble(secondInput);
        	if(firstInput1 < secondInput1)
        		return true;
        	return false;
    	}
    	else {
    		 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-mm-dd");  
 		    SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-mm-dd");
 		    Date date1=formatter1.parse(firstInput);  
 		    Date date2=formatter2.parse(secondInput);  
 		    if(date1.compareTo(date2) < 0) {
 		    	return true;
 		    }
 		    return false;
    	}
    	
    } 
	
	
	
	
	//Method containing implementation of lessThanOrEqualTo operator
    public boolean lessThanOrEqualTo(String firstInput,String secondInput, String dataType) throws Exception {
    	if(dataType.equals("java.lang.Integer")) {
    		Integer firstInput1=Integer.parseInt(firstInput);
        	Integer secondInput1=Integer.parseInt(secondInput);
    	if(firstInput1 <= secondInput1)
    		return true;
    	return false;
    	}
    	else if(dataType.equals("java.lang.Double")) {
    		Double firstInput1=Double.parseDouble(firstInput);
        	Double secondInput1=Double.parseDouble(secondInput);
        	if(firstInput1 <= secondInput1)
        		return true;
        	return false;
    	}
    	else {
    		 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-mm-dd");  
 		    SimpleDateFormat formatter2=new SimpleDateFormat("yyyy-mm-dd");
 		    Date date1=formatter1.parse(firstInput);  
 		    Date date2=formatter2.parse(secondInput);  
 		    if(date1.compareTo(date2) <= 0) {
 		    	return true;
 		    }
 		    return false;
    	}
    	
    }

	
}
