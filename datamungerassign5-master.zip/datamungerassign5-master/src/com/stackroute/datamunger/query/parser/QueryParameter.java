package com.stackroute.datamunger.query.parser;

import java.util.List;
/* 
 * This class will contain the elements of the parsed Query String such as conditions,
 * logical operators,aggregate functions, file name, fields group by fields, order by
 * fields, Query Type
 * */
public class QueryParameter {
	private String fileName;
	private String queryString;
	private String baseQuery;
	private final String QUERY_TYPE = "";
	private List<String> fields;
	private List<String> logicalOperators;
	private List<String> orderByFields;
	private List<String> groupByFields;
	private List<AggregateFunction> aggregateFunction;
	private List<Restriction> restrictions;

	public String getQuerystring() {
		return queryString;
	}
	public void setQueryString(String qString) {
		this.queryString=qString;
	}
	public String getFileName() {
		// TODO Auto-generated method stub
		return fileName;
	}

	public List<String> getFields() {
		// TODO Auto-generated method stub
		return fields;
	}

	public List<Restriction> getRestrictions() {
		// TODO Auto-generated method stub
		return restrictions;
	}

	public String getBaseQuery() {
		// TODO Auto-generated method stub
		return baseQuery;
	}

	public List<AggregateFunction> getAggregateFunctions() {
		// TODO Auto-generated method stub
		return aggregateFunction;
	}

	public List<String> getLogicalOperators() {
		// TODO Auto-generated method stub
		return logicalOperators;
	}

	public List<String> getGroupByFields() {
		// TODO Auto-generated method stub
		return groupByFields;
	}

	public List<String> getOrderByFields() {
		// TODO Auto-generated method stub
		return orderByFields;
	}

	public String getQUERY_TYPE() {
		// TODO Auto-generated method stub
		return QUERY_TYPE;
	}

	public void setFileName(String file1) {
		// TODO Auto-generated method stub
		this.fileName=file1;
	}

	public void setBaseQuery(String baseQuery1) {
		// TODO Auto-generated method stub
		this.baseQuery=baseQuery1;
	}

	public void setOrderByFields(List<String> orderByFields1) {
		// TODO Auto-generated method stub
		this.orderByFields=orderByFields1;
		
	}

	public void setAggregateFunctions(List<AggregateFunction> aggregateFunction1) {
		// TODO Auto-generated method stub
		this.aggregateFunction=aggregateFunction1;
	}

	public void setLogicalOperators(List<String> logicalOperators1) {
		// TODO Auto-generated method stub
		this.logicalOperators=logicalOperators1;
	}

	public void setRestrictions(List<Restriction> restriction1) {
		// TODO Auto-generated method stub
		this.restrictions=restriction1;
		
	}
	public void setFields(List<String> field) {
		// TODO Auto-generated method stub
		this.fields=field;
		
	}
	public void setGroupByFields(List<String> groupByFields1) {
		// TODO Auto-generated method stub
		this.groupByFields=groupByFields1;
		
	}

		

	
}
