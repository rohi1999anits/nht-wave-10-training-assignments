package com.stackroute.datamunger.query.parser;

import java.util.ArrayList;
import java.util.List;

public class QueryParser {

	QueryParameter queryParameter=new QueryParameter();
	/*
	 * This method will parse the queryString and will return the object of
	 * QueryParameter class
	 */
	public QueryParameter parseQuery(String queryString) {
		queryParameter.setQueryString(queryString);
		queryParameter.setFileName(getFile1(queryString));
		queryParameter.setBaseQuery(getBaseQuery1(queryString));
    	queryParameter.setOrderByFields(getOrderByFields1(queryString));
		queryParameter.setGroupByFields(getGroupByFields1(queryString));
        queryParameter.setFields(getField(queryString));
        queryParameter.setAggregateFunctions(getAggregateFunction1(queryString));
        queryParameter.setLogicalOperators(getLogicalOperators1(queryString));
	    queryParameter.setRestrictions(getRestriction1(queryString));
		return queryParameter;
	}
	
	
		/*
		 * extract the name of the file from the query. File name can be found after the
		 * "from" clause.
		 */
		private String getFile1(String qString) {
			String words=qString.toLowerCase().split("from")[1].trim().split(" ")[0].trim(); 
		   	  return words.trim();
	   	 }
		
		private String getBaseQuery1(String qString) {
	    	 String words=qString.split(" where| group by | order by")[0].trim(); 
	    	 return words;
			}
		/*
		 * extract the order by fields from the query string. Please note that we will
		 * need to extract the field(s) after "order by" clause in the query, if at all
		 * the order by clause exists. For eg: select city,winner,team1,team2 from
		 * data/ipl.csv order by city from the query mentioned above, we need to extract
		 * "city". Please note that we can have more than one order by fields.
		 */
		private List<String> getOrderByFields1(String qString){
			 qString=qString.toLowerCase();
	    	 List<String> newList=new ArrayList<>();
			  if(!qString.contains("order by "))
				  return newList;
			  String[] words=qString.split("order by")[1].trim().split(",");  
			  for(int i=0;i<words.length;i++) {
				  if(words[i].contains(" asc") || words[i].contains(" desc")) 
	                      newList.add(words[i].split(" asc| desc")[0].trim());
	             else
	           	  newList.add(words[i].trim());           	   
			  }
			  return newList;
	     }
		
		/*
		 * extract the group by fields from the query string. Please note that we will
		 * need to extract the field(s) after "group by" clause in the query, if at all
		 * the group by clause exists. For eg: select city,max(win_by_runs) from
		 * data/ipl.csv group by city from the query mentioned above, we need to extract
		 * "city". Please note that we can have more than one group by fields.
		 */
		public List<String> getGroupByFields1(String queryString) {
			 queryString=queryString.toLowerCase();
			  List<String> newList=new ArrayList<>();
			 if(!queryString.contains("group by"))
				 return newList;
		  String[] words=queryString.split("group by ")[1].trim().split("order by")[0].trim().split(","); 
		  for(String word:words) {
	       	  newList.add(word.trim());              	   
		  }
		  return newList;
		  }

		
		/*
		 * extract the selected fields from the query string. Please note that we will
		 * need to extract the field(s) after "select" clause followed by a space from
		 * the query string. For eg: select city,win_by_runs from data/ipl.csv from the
		 * query mentioned above, we need to extract "city" and "win_by_runs". Please
		 * note that we might have a field containing name "from_date" or "from_hrs".
		 * Hence, consider this while parsing.
		 */
		private List<String> getField(String qString){
			 String[]  words=qString.trim().split("select")[1].split("from")[0].trim().split(",");
	    	 List<String> wordList=new ArrayList<>();
	    	 for(String word:words) {
	    		 wordList.add(word.trim());
	    	 }
	    	 return wordList;
	     }
		
		
		
		/*
		 * extract the conditions from the query string(if exists). for each condition,
		 * we need to capture the following: 
		 * 1. Name of field 
		 * 2. condition 
		 * 3. value
		 * 
		 * For eg: select city,winner,team1,team2,player_of_match from data/ipl.csv
		 * where season >= 2008 or toss_decision != bat
		 * 
		 * here, for the first condition, "season>=2008" we need to capture: 
		 * 1. Name of field: season 
		 * 2. condition: >= 
		 * 3. value: 2008
		 * 
		 * the query might contain multiple conditions separated by OR/AND operators.
		 * Please consider this while parsing the conditions.
		 * 
		 */
		public List<Restriction> getRestriction1(String queryString) {
			List<Restriction> myList=new ArrayList<>();
			  Restriction res;
			  String[] words=null;
			  if(queryString.contains("where")){
			  		if(queryString.contains("where") || queryString.contains("group by") || queryString.contains("order by")){
			  		 words=queryString.split("where")[1].trim().split("group by | order by")[0].trim().split(" and|or ");		 
			  		}
			  }
			  else
				  return null;
			  String propName;
			  String propValue;
			  String condition;
			  String[] strArr;
			  if(queryString!=null) {
				  for(String s:words) {
					  s=s.trim();
					  strArr=s.split("<=|>=|<|>|!=|=");
					  propName=strArr[0].trim();
					  propValue=strArr[1].trim().replace("'","");
					  condition=s.split(propName)[1].trim().split(propValue)[0].trim().replace("'", "");
					  res=new Restriction(propName,propValue,condition);//.split(propValue)[0].trim();
					  myList.add(res);
				  }
			
			  }
			  return myList;
	     }
		
		/*
		 * extract the logical operators(AND/OR) from the query, if at all it is
		 * present. For eg: select city,winner,team1,team2,player_of_match from
		 * data/ipl.csv where season >= 2008 or toss_decision != bat and city =
		 * bangalore
		 * 
		 * the query mentioned above in the example should return a List of Strings
		 * containing [or,and]
		 */
		public List<String> getLogicalOperators1(String queryString) { 
			String[] words=queryString.toLowerCase().split(" "); 
	 	    List<String> newList=new ArrayList<>();
	 	   for(int i=0;i<words.length;i++) {
				  if(words[i].equalsIgnoreCase("and")) 
					  newList.add("and");
				  if(words[i].equalsIgnoreCase("or")) 
					  newList.add("or");
				  if(words[i].equalsIgnoreCase("not")) {
					  newList.add("not");}
			  }
	 	   if(newList.isEmpty())
	 		   return null;
	 	   else
			  return newList;
		  }

		
		/*
		 * extract the aggregate functions from the query. The presence of the aggregate
		 * functions can determined if we have either "min" or "max" or "sum" or "count"
		 * or "avg" followed by opening braces"(" after "select" clause in the query
		 * string. in case it is present, then we will have to extract the same. For
		 * each aggregate functions, we need to know the following: 
		 * 1. type of aggregate function(min/max/count/sum/avg) 
		 * 2. field on which the aggregate function is being applied
		 * 
		 * Please note that more than one aggregate function can be present in a query
		 * 
		 * 
		 */
		 public List<AggregateFunction> getAggregateFunction1(String qString) {
			 List<AggregateFunction> newList=new ArrayList<>();
	    	 AggregateFunction obj;
	    	 qString=qString.toLowerCase();
	    	 String[] strArr=null;
	 	        String[] words=qString.split("select")[1].trim().split("from")[0].trim().split(",");
	 	        for(int i=0;i<words.length;i++) {
	 	        	strArr=words[i].trim().split("[(]");
	 	        	if(strArr.length>1) {
	 	        	obj=new AggregateFunction(strArr[1].trim().substring(0,strArr[1].length()-1),strArr[0].trim());
	 	            newList.add(obj);
	 	        	}
	 	        }
	 	      return newList;  
		 }
}
