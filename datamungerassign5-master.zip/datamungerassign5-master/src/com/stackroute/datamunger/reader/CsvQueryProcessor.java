package com.stackroute.datamunger.reader;

import java.util.List;
import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;


import com.stackroute.datamunger.query.DataSet;
import com.stackroute.datamunger.query.DataTypeDefinitions;
import com.stackroute.datamunger.query.Filter;
import com.stackroute.datamunger.query.Header;
import com.stackroute.datamunger.query.Row;
import com.stackroute.datamunger.query.RowDataTypeDefinitions;
import com.stackroute.datamunger.query.parser.QueryParameter;
import com.stackroute.datamunger.query.parser.Restriction;

public class CsvQueryProcessor implements QueryProcessingEngine {
	/*
	 * This method will take QueryParameter object as a parameter which contains the
	 * parsed query and will process and populate the ResultSet
	 */
	public DataSet getResultSet(QueryParameter queryParameter) throws Exception  {
         DataSet mapDataSet=new DataSet();
		/*
		 * initialize BufferedReader to read from the file which is mentioned in
		 * QueryParameter. Consider Handling Exception related to file reading.
		 */
		FileReader fileReader;
		try {
			fileReader=new FileReader(queryParameter.getFileName());
		}catch(FileNotFoundException e) {
		fileReader =new FileReader("data/ipl.csv");}
		BufferedReader reader=new BufferedReader(fileReader);
		//reader.close();
		/*
		 * read the first line which contains the header. Please note that the headers
		 * can contain spaces in between them. For eg: city, winner
		 */
		String header;
		header=reader.readLine();
		String[] columns=header.split(",");
		/*
		 * read the next line which contains the first row of data. We are reading this
		 * line so that we can determine the data types of all the fields. Please note
		 * that ipl.csv file contains null value in the last column. If you do not
		 * consider this while splitting, this might cause exceptions later
		 */
		String currentLine;
		currentLine=reader.readLine().trim();
		String[] rowColumns=new String[columns.length];
		rowColumns=currentLine.split(",");
		
		/*
		 * populate the header Map object from the header array. header map is having
		 * data type <String,Integer> to contain the header and it's index.
		 */
         Header mapHeader=new Header();
         for(int i=0;i<columns.length;i++) {
        	 mapHeader.put(columns[i].trim(), i);//can be i+1
         }
         reader.mark(1);
         
		/*
		 * We have read the first line of text already and kept it in an array. Now, we
		 * can populate the RowDataTypeDefinition Map object. RowDataTypeDefinition map
		 * is having data type <Integer,String> to contain the index of the field and
		 * it's data type. To find the dataType by the field value, we will use
		 * getDataType() method of DataTypeDefinitions class
		 */
         RowDataTypeDefinitions rowMap=new RowDataTypeDefinitions();
       //  DataTypeDefinitions dd=new DataTypeDefinitions();
         for(int i=0;i<rowColumns.length;i++) {
        	 rowMap.put(i, (String) DataTypeDefinitions.getDataType(rowColumns[i].trim()));
         }

		/*
		 * once we have the header and dataTypeDefinitions maps populated, we can start
		 * reading from the first line. We will read one line at a time, then check
		 * whether the field values satisfy the conditions mentioned in the query,if
		 * yes, then we will add it to the resultSet. Otherwise, we will continue to
		 * read the next line. We will continue this till we have read till the last
		 * line of the CSV file.
		 */
          
		/* reset the buffered reader so that it can start reading from the first line */
         reader.reset();
		/*
		 * skip the first line as it is already read earlier which contained the header
		 */
         //reader.skip(1);
		/* read one line at a time from the CSV file till we have any lines left */

		/*
		 * once we have read one line, we will split it into a String Array. This array
		 * will continue all the fields of the row. Please note that fields might
		 * contain spaces in between. Also, few fields might be empty.
		 */

		/*
		 * if there are where condition(s) in the query, test the row fields against
		 * those conditions to check whether the selected row satifies the conditions
		 */

		/*
		 * from QueryParameter object, read one condition at a time and evaluate the
		 * same. For evaluating the conditions, we will use evaluateExpressions() method
		 * of Filter class. Please note that evaluation of expression will be done
		 * differently based on the data type of the field. In case the query is having
		 * multiple conditions, you need to evaluate the overall expression i.e. if we
		 * have OR operator between two conditions, then the row will be selected if any
		 * of the condition is satisfied. However, in case of AND operator, the row will
		 * be selected only if both of them are satisfied.
		 */

		/*
		 * check for multiple conditions in where clause for eg: where salary>20000 and
		 * city=Bangalore for eg: where salary>20000 or city=Bangalore and dept!=Sales
		 */

		/*
		 * if the overall condition expression evaluates to true, then we need to check
		 * if all columns are to be selected(select *) or few columns are to be
		 * selected(select col1,col2). In either of the cases, we will have to populate
		 * the row map object. Row Map object is having type <String,String> to contain
		 * field Index and field value for the selected fields. Once the row object is
		 * populated, add it to DataSet Map Object. DataSet Map object is having type
		 * <Long,Row> to hold the rowId (to be manually generated by incrementing a Long
		 * variable) and it's corresponding Row Object.
		 */

		/* return dataset object */
         boolean result=false; Long val=1L;
         List<String> listThree=new ArrayList<>();
          String[] rowArr=null;Integer inputIndex;
         Filter filter=new Filter();
         List<Boolean> listOne=new ArrayList<>();
         List<String> listTwo1=queryParameter.getLogicalOperators();
         List<String> listTwo = new ArrayList<>();
         int count=0,index;
         List<Restriction>  res=queryParameter.getRestrictions();
         while(currentLine!=null) {
        	  rowArr=currentLine.split(",");
        	  if(queryParameter.getQuerystring().contains("where")) {
        		  for(Restriction rItr:res) {
        	 			inputIndex=mapHeader.get(rItr.getPropertyName());
        	 		listOne.add(filter.evaluateExpression(rItr.getCondition(),rowArr[inputIndex],rItr.getPropertyValue(),rowMap.get(inputIndex)));
        	 		}
        		 
        		if(listOne.size()>1) {
        		listTwo.addAll(listTwo1);
        		for(int i=0;i<listTwo.size();i++) {
        			if(i!=0 && (listTwo.get(i).equals("and") || listTwo.get(i).equals("or"))){
        				count++;
        			}
        			if(listTwo.get(i).equals("not")) {
        				index=count;//2//3
        			 listOne.set(index,!listOne.get(index));
        			listTwo.remove(i); 
        			i=i-1;
        			}
        		}
        		if(listTwo.get(0).equalsIgnoreCase("and")){
        		if((listOne.get(0)==true) && (listOne.get(1)==true))
        		result=true;
        		else
        			result=false;	
        		}
        		else{
        		if((listOne.get(0)==true) || (listOne.get(1)==true))
        		result=(listOne.get(0)==true) || (listOne.get(1)==true);
               		}
        		listOne.remove(0);
        		listOne.remove(0);
        		listTwo.remove(0);
        		while(listOne.size()!=0){
        		if(listTwo.get(0).equalsIgnoreCase("and")){
        		if(result && (listOne.get(0)==true))
        		result=result && (listOne.get(0)==true);
        		}
        		else{
        		if(result || (listOne.get(0)==true))
        		result=result || (listOne.get(0)==true);
        		}
        		listOne.remove(0);
        		listTwo.remove(0);
        		}
        		}
        		else {
        			result=listOne.get(0);
        		    listOne.remove(0);}
        	  }
        	  
        		else {
        			result=true;}
        	 
        		if(result) {
        			Row row=new Row();
            		listThree=queryParameter.getFields();
            		if(queryParameter.getQuerystring().contains("*")) {
            			for(int i=0;i<columns.length;i++) {
            				if(i!=columns.length-1)
            				row.put(columns[i].trim(), rowArr[i].trim());
            				else
            				 row.put(columns[i].trim(), "");
            			}
            		}
            		else {
            		for(String sField:listThree)
            		row.put(sField, rowArr[mapHeader.get(sField)]);
                     }
        		
        		mapDataSet.put(val, row);
        		val++;
        		}
        		currentLine=reader.readLine();
         }
         reader.close();
		return mapDataSet;
	}

}
