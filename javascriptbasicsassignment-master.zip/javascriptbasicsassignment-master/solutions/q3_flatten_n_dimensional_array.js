/* Write a Program to Flatten a given n-dimensional array */

const flatten = (array) => {
	// Write your code here
	//var newArray = Array.prototype.concat.apply([], oldArray);
	if(!Array.isArray(array)){
		return null;
	}
	var newArray=array.flat(Infinity);//ECMA version
	return newArray;
};

/* For example,
INPUT - flatten([1, [2, 3], [[4], [5]])
OUTPUT - [ 1, 2, 3, 4, 5 ]

*/

module.exports = flatten;
//oldArr=[1, [2, 3], [[4], [5]]];
flatten([1, [2, 3], [[4, 5], [6, 7]], [[[8, 9], 10]]])
//console.log(flatten([1, [2, 3], [[4, 5], [6, 7]], [[[8, 9], 10]]]));