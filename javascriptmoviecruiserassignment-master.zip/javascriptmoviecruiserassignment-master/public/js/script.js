  
let movies = [];
let favourites = [];
let moviesURL = 'http://localhost:3000/movies';
let favURL = 'http://localhost:3000/favourites';
let count=0;

/* Function to return movies */
//class="img-response img-thumbnail" is a inbuilt bootstrap class for image responsiveness and alignment
//listMovies is called in getMovies method
//ECMA script-template literals:(with back ticks-`)`${...}` :here  fetched db.json values and ued to convert to respective type
function moviesList(movies) {
	let doc='';
	movies.forEach(ele => {
		doc=doc+`<li>
		<div id="${ele.id}" class="list-group-item d-flex flex-column align-items-center">
		<div class="row">
		<div class="col-12 col-md-6">
		<img src="${ele.posterPath}"  class="img-response img-thumbnail" />
		</div>
		<div class="col-12 col-md-6">
		<div><h4>${ele.title} </h4></div>
		<div class="overview"> ${ele.overview} </div>
		<div><button onclick="addFavourite(${ele.id})" type="button" 
		class="btn btn-primary">Add To Favourites</button></div>
		</div>
		</div>
		</li>`;
		});
	let movEle = document.getElementById('moviesList');
	movEle.innerHTML = doc;
}

//Flow of program: 1)getMovies<--->listMovies(write to html)---->addFavourite<---->getFavourite<--->listFavourites(write to html)
/* Function to get list of movies */
function getMovies() {
	return fetch(moviesURL)
	.then(response => { if(response.ok){         
		return response.json();          
}
else if(response.status == 404){
	return Promise.reject(new Error('Invalid URL'))
}
else if(response.status == 401){
	return Promise.reject(new Error('UnAuthorized User...'));
}
else{
	return Promise.reject(new Error('Internal Server Error'));
}
}).then(resp => {
		movies = resp;
		moviesList(movies);
		return resp;
	})
	.catch((err)=> { throw new Error(err); });
}


/* Function to return favourites */
function favouritesList(favourites) {
	let doc='';
	favourites.forEach(ele => {
		doc=doc+`<li>
		<div id="${ele.id}" class="list-group-item d-flex flex-column align-items-center">
		<div class="row">
		<div class="col-12 col-md-6">
		<img src="${ele.posterPath}"  class="img-response img-thumbnail" />
		</div>
		<div class="col-12 col-md-6">
		<div><h4>Favorites : ${++count}</h4></div>
		<div> ${ele.title} </h4></div>
		<div class="overview"> ${ele.overview} </div>
		</div>
		</div>
		</li>`;
		});
	let favEle = document.getElementById('favouritesList');
	favEle.innerHTML = doc;
}

/* Function to get list of favourites */
function getFavourites() {
return fetch(favURL)
	.then(response => {
		if(response.ok){         
				return response.json();          
		}
		else if(response.status == 404){
			return Promise.reject(new Error('Invalid URL'))
		}
		else if(response.status == 401){
			return Promise.reject(new Error('UnAuthorized User...'));
		}
		else{
			return Promise.reject(new Error('Internal Server Error'));
		}}).then(resp => {
		favourites = resp;
		favouritesList(favourites);
	return resp;
})
.catch((err)=> { throw new Error(err); });
}

//adding favorites to localhost:3000/favorites through POST http method
//while fetching convert into json object(using .json())(so that it can easily map to js object and collections/HOF can be applied) 
//while posting convert object to json string(using json.stringify())
/* Function to add favourite from ID */
function addFavourite(id) {
	//after fetching data from port 3000 and putting into movies(list)
let mov = movies.filter(m => {
    return m.id === id;
  });
let fav = favourites.filter(f => {
    return f.id === id;
  });
	 if(fav.length > 0) {
		return Promise.reject(new Error('Movie is already added to favourites'));
	}
	else {
		return fetch(favURL, {
			method: 'POST',
			body: JSON.stringify(mov[0]),
			headers: { 'Content-Type': 'application/json' }
		}).then(function(response) {
			if(response.ok){
				return response.json();
			}
		}
	).then(function(fav1) {
			favourites.push(fav1);
			favouritesList(favourites);
			return favourites;
		});
	}
}
	

module.exports = {
	getMovies,
	getFavourites,
	addFavourite
};
// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution