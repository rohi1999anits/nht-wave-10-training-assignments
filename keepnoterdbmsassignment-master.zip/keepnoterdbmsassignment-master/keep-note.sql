create table Note(
note_id int primary key,
note_title varchar(25) not null,
note_content varchar(100) not null,
note_status varchar(15) not null,
note_creation_date datetime not null);

create table Category(
category_id int primary key,
category_name varchar(10) not null unique,
category_descr varchar(50) not null,
category_creation_date datetime not null,
category_creator varchar(15) not null);

create table Reminder(
reminder_id int primary key,
reminder_name varchar(15) not null unique,
reminder_descr varchar(50) not null,
reminder_type varchar(15) not null,
reminder_creation_date datetime not null,
reminder_creator varchar(15) not null);

create table User(
user_id varchar(5) primary key,
user_name varchar(10) not null,
user_added_date datetime not null,
user_password varchar(8) not null,
user_mobile varchar(10)
);

create table UserNote(
usernote_id int primary key,
user_id varchar(5) not null,
note_id int not null
);

create table NoteReminder(
notereminder_id int primary key,
note_id int not null,
reminder_id int not null
);

create table NoteCategory(
notecategory_id int primary key,
note_id int not null,
category_id int not null
);

insert into Note values (1, 'To kill a mocking bird', 'To Kill a Mockingbird is a novel by the American author Harper Lee.', 'completed','1960-05-16 06:20:19'),
(2, 'Wings of fire', 'An Autobiography of A P J Abdul Kalam (1999), former President of India.','completed', '1999-03-04 09:20:40');

insert into Category values (1, 'Thriller', 'The Girl on the Train', '1960-05-16 06:20:19', 'Good Reads'),
(2, 'Fiction', 'To kill a mocking bird', '1999-03-04 09:20:40', 'Scribd');

insert into Reminder values (1, 'ToDolist', 'list of todo items', 'Listings', '1960-05-16 06:20:19', 'Admin'),
(2, 'checkList', 'daily reminders', 'Listings', '1999-03-04 09:20:40', 'stranger');

insert into User values ('1', 'Admin', '1960-05-16 06:20:19', 'Password', '7777777777'),
(2, 'stranger', '1999-03-04 09:20:40', 'Password', '5555555555');

insert into UserNote values (1, '1', 1), 
(2, '1', 2);

insert into NoteReminder values (1, 1, 1),
 (2, 2, 2);

insert into NoteCategory values (1, 1, 1), 
(2, 2, 2);

select * from User where user_id='1' and user_password='Password';

select * from Note where note_creation_date='1999-03-04 09:20:40';

select * from Category where category_creation_date>'1950-11-10 08:30:42';

select note_id from UserNote where user_id='1';

update Note set note_status='not started' where note_id=2;

select n.note_id, n.note_title, n.note_content, n.note_status, n.note_creation_date from note n INNER JOIN usernote u 
ON n.note_id=u.note_id and u.user_id=2;

select n.note_id, n.note_title, n.note_content, n.note_status, n.note_creation_date from 
Note n INNER JOIN NoteCategory nc ON n.note_id=nc.note_id and nc.category_id=2 ;

select r.reminder_id, r.reminder_name, r.reminder_descr, r.reminder_type, r.reminder_creation_date, 
r.reminder_creator from Reminder r INNER JOIN NoteReminder nr ON r.reminder_id=nr.reminder_id and nr.note_id=1;

select* from Reminder where reminder_id=2;

insert into Note values (3, 'Outliers', 'he Story of Success is the third non-fiction book written by Malcolm Gladwell', 'started','2018-11-18 06:20:19');
insert into UserNote values (3, '3', 3);

insert into Note values (4, 'The Girl on the Train', 'thiller story', 'not started','2015-11-18 06:20:19');
insert into NoteCategory values (3, 4, 3);

insert into Reminder values (3, 'myTasks', 'complete Assignment', 'NoteView', '2021-05-11 06:20:19', 'Admin');
insert into NoteReminder values (3, 3, 3);

delete n, un from Note as n INNER JOIN UserNote as un ON n.note_id=un.note_id WHERE un.user_id='1';

delete n, nc from note n INNER JOIN notecategory nc ON n.note_id=nc.note_id WHERE nc.category_id=1;














