package com.stackroute.keepnote.exception;

public class CategoryNotCreatedException extends Exception {
   
	private static final long serialVersionUID = 1L;

	public CategoryNotCreatedException(String message) {
        super(message);
    }
}
