// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast


// Write your code here

const fruitArr=[
    {name:'mango',color:'yellow',price:400},
    {name:'apple',color:'red',price:200},
    {name:'grapes',color:'green',price:100},
    {name:'orange',color:'orange',price:160}
];
const convert=(fruitArr1,key)=>{
    if(Array.isArray(fruitArr1)){
const convertToObject=(fruitArr1,key)=>
fruitArr1.reduce((obj,item) => {
    obj[item[key]]=item;
    return obj;
}, {});
return convertToObject(fruitArr1,key);
}
else
return null;
}

const fruitObj=convert(fruitArr,'name');
console.log(fruitObj);
console.log(fruitObj.mango);
console.log(fruitObj.grapes);

module.exports = convert;
