// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.
var c=0;
var sum,per;
let list=[];
    const studentsList=[{name:'kiran',subjects:[{subject:'Grammer',marks:70},{subject:'Accounts',marks:83}]},
    {name:'pavan',subjects:[{subject:'Grammer',marks:65},{subject:'Accounts',marks:88}]},
    // {name:'rick',subjects:[{subject:'Grammer',marks:90},{subject:'Accounts',marks:68}]},
    // {name:'robert',subjects:[{subject:'Grammer',marks:76},{subject:'Physics',marks:69}]},
    // {name:'avani',subjects:[{subject:'Grammer',marks:82},{subject:'Physics',marks:53}]},
    {name:'sindhuri',subjects:[{subject:'Grammer',marks:54},{subject:'Physics',marks:44}]},
    {name:'anil',subjects:[{subject:'Grammer',marks:68},{subject:'Physics',marks:90}]}];
    const results=(studentsList)=>{
        list=[];
        if(!Array.isArray(studentsList)){
            return null;
        }
        console.log(studentsList.length);
        for(var i=0;i<studentsList.length;i++){
     item=studentsList[i];
    sum=item.subjects[0].marks+item.subjects[1].marks;
    per=sum/item.subjects.length;
    list.push({ 'name':item.name,'percentage':per});
    };
    return list;
}
//results(studentsList);
//console.log(results(studentsList).length);
console.log(results(studentsList));
module.exports=results;