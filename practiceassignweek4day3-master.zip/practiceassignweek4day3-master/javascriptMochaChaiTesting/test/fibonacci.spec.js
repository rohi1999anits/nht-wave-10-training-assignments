const Fibonacci=require('../Fibonacci.js');
let chai = require('chai');
let expect = chai.expect;

let fib;
fib = new Fibonacci();
before(() =>{
    console.log("Beginning of the test cases");
});
after(() =>{
    console.log("End of the test cases");
});
describe('Fibonacci Test Suite-1',()=>{
describe('This will test an object for array format',()=>
{
    it('Must have array structure',()=>
    {
        expect(fib.fibonacci(5)).to.be.an('Array');
    })
});

describe('test the null return values of the Fibonacci method', () => {
    it('Must  return undefined', () => {
        expect(fib.fibonacci('')).to.deep.equal(null);
    });
});
});
describe('Fibonacci Test Suite-2',()=>{
    describe('test the VALID return values of the Fibonacci method', () => {
        it('Must return 0', () => {
            expect(fib.fibonacci(0)).to.deep.equal([0]);
        });
        it('should return 0, 1', () => {
            expect(fib.fibonacci(1)).to.deep.equal([0, 1]);
        });
        it('should return 0, 1, 1', () => {
            expect(fib.fibonacci(2)).to.deep.equal([0, 1, 1]);
        });
        it('should return 0, 1, 1, 2', () => {
            expect(fib.fibonacci(3)).to.deep.equal([0, 1, 1, 2]);
        });
        it('should return 0, 1, 1, 2, 3, 5, 8', () => {
            expect(fib.fibonacci(6)).to.deep.equal([0, 1, 1, 2, 3, 5, 8]);
        });
        it('should return 0, 1, 1, 2, 3, 5, 8, 13, 21, 34', () => {
            expect(fib.fibonacci(9)).to.deep.equal([0, 1, 1, 2, 3, 5, 8, 13, 21, 34]);
        });
        it('should return 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55', () => {
            expect(fib.fibonacci(10)).to.deep.equal([0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]);
        });
    });
});
//'to.deep.equal' equivalent to 'to.eql' <=> '==='
//to.equal is normal '=='
describe('Fibonacci Test Suite-3',()=>{
    describe('test the INVALID return values of the Fibonacci method', () => {
        it('should not return 0', () => {
            expect(fib.fibonacci(0)).to.not.eql([]);
        });
        it('should not return 0', () => {
            expect(fib.fibonacci(0)).to.not.eql([-1]);
        });
        it('should not return 0', () => {
            expect(fib.fibonacci(0)).to.not.eql([1]);
        });

        it('should not return 1', () => {
            expect(fib.fibonacci(1)).to.not.eql([]);
        });
        it('should not return 1', () => {
            expect(fib.fibonacci(1)).to.not.eql([-1]);
        });
        it('should not return 1', () => {
            expect(fib.fibonacci(1)).to.not.eql([0]);
        });
        it('should not return 1', () => {
            expect(fib.fibonacci(1)).to.not.eql([1]);
        });

        it('should not return 2', () => {
            expect(fib.fibonacci(2)).to.not.eql([]);
        });
        it('should not return 2', () => {
            expect(fib.fibonacci(2)).to.not.eql([1]);
        });
        it('should not return 2', () => {
            expect(fib.fibonacci(2)).to.not.eql([0, 1]);
        });

        it('should not return 2', () => {
            expect(fib.fibonacci(2)).to.not.eql([0, 1, 1, 2]);
        });
        it('should not return 2', () => {
            expect(fib.fibonacci(2)).to.not.eql([2]);
        });

    });
});
describe('Fibonacci Test Suite-4',()=>{
    describe('test the data type of the Parameter of the Fibonacci method', () => {
        it('should throw the exception: "The Parameter must be an Integer!"', () => {
            expect(() => fib.fibonacci('2')).to.throw('The Parameter must be an Integer!');
        });
        it('should throw the exception: "The Parameter must be an Integer!"', () => {
            expect(() => fib.fibonacci(['8'])).to.throw('The Parameter must be an Integer!');
        });
        it('should throw the exception: "The Parameter must be an Integer!"', () => {
            expect(() => fib.fibonacci(5.888)).to.throw('The Parameter must be an Integer!');
        });
        it('should NOT throw the exception: "The Parameter must be an Integer!"', () => {
            expect(() => fib.fibonacci(2)).to.not.throw('The Parameter must be an Integer!');
        });
    });
});
describe('Fibonacci Test Suite-5',()=>{
    describe('test the value of the Parameter of the Fibonacci method', () => {
        it('should throw the exception: "The Parameter must be positive!"', () => {
            expect(() => fib.fibonacci(-5)).to.throw('The Parameter must be positive!');
        });
        it('should throw the exception: "The Parameter must be positive!"', () => {
            expect(() => fib.fibonacci(-1000)).to.throw('The Parameter must be positive!');
        });
        it('should not throw the exception: "The Parameter must be positive!"', () => {
            expect(() => fib.fibonacci(20)).to.not.throw('The Parameter must be positive!');
        });
        it('should not throw the exception: "The Parameter must be positive!"', () => {
            expect(() => fib.fibonacci(0)).to.not.throw('The Parameter must be positive!');
        });
        it('should not throw the exception: "The Parameter must be positive!"', () => {
            expect(() => fib.fibonacci(2)).to.not.throw('The Parameter must be positive!');
        });
    });
});
