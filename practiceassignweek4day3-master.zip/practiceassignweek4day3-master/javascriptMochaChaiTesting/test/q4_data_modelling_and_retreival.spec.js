const chai = require('chai');
const expect = chai.expect;
const convert = require('../q4_data_modelling_and_retreival.js');
const assert = require('chai').assert;
const testObj = [  {name:'mango',color:'yellow',price:400},
{name:'apple',color:'red',price:200},
{name:'orange',color:'orange',price:160}];

const testObj1 = [  {name:'mango',color:'yellow',price:400},
{name:'apple',color:'red',price:200},
{name:'grapes',color:'green',price:100},
{name:'orange',color:'orange',price:160}];

describe('Testing - data_modelling_and_retreival', () => {
	it('module return type test case', (done) => {
		assert.isFunction(convert);
		done();
	});

	it('function return type test case', (done) => {
		assert.isObject(convert(testObj,'name'));
		done();
	});
    
	it('positive test case 1', (done) => {
assert.deepEqual({
				mango: {name:'mango',color:'yellow',price:400},
	apple:{name:'apple',color:'red',price:200},
	grapes:{name:'grapes',color:'green',price:100},
	orange:{name:'orange',color:'orange',price:160}
				}, convert(testObj1, 'name'));
		done();
	
	});
it('positive test case 2', (done) => {
 assert.deepEqual({
    mango: {name:'mango',color:'yellow',price:400},
    apple:{name:'apple',color:'red',price:200},
    orange:{name:'orange',color:'orange',price:160}
        }, convert(testObj, 'name'));
        done();
            });

	it('negative test case 1', (done) => {
	assert.deepEqual(null,convert('invalid value'));
		done();
	});
    it('negative test case2', (done) => {
        assert.notDeepEqual({
            mango :{name:'mango',color:'yellow',price:400}});
        done();
        });
});
