const chai = require('chai');
const expect = chai.expect;
const results = require('../q5_result_cards.js');
const assert = require('chai').assert;

const testObj = [{name:'kiran',subjects:[{subject:'Grammer',marks:70},{subject:'Accounts',marks:83}]},
{name:'pavan',subjects:[{subject:'Grammer',marks:65},{subject:'Accounts',marks:88}]}];

const testObj1 = [{name:'kiran',subjects:[{subject:'Grammer',marks:70},{subject:'Accounts',marks:83}]},
{name:'pavan',subjects:[{subject:'Grammer',marks:65},{subject:'Accounts',marks:88}]},
{name:'sindhuri',subjects:[{subject:'Grammer',marks:54},{subject:'Physics',marks:44}]},
    {name:'anil',subjects:[{subject:'Grammer',marks:68},{subject:'Physics',marks:90}]}];
describe('Testing - students_result_cards', () => {
	it('module return type test case', (done) => {
		assert.isFunction(results);
		done();
	});

	it('function return type test case', (done) => {
        assert.isArray(results(testObj));
		done();
	});   
	it('positive test case1', (done) => {
assert.deepEqual([
    { name: 'kiran', percentage: 76.5 },
    { name: 'pavan', percentage: 76.5 }
  ], results(testObj));
  done();
});
  it('positive test case2', (done) => {
  assert.lengthOf(results(testObj),2);
		done();
	});
 it('positive test case 3', (done) => {
        assert.deepEqual([
            { name: 'kiran', percentage: 76.5 },
            { name: 'pavan', percentage: 76.5 },
            { name: 'sindhuri', percentage: 49 },
            { name: 'anil', percentage: 79 }], results(testObj1));
          done();
    });
 it('positive test case 4', (done) => {
    assert.lengthOf(results(testObj1),4);
        done();
     });

	it('negative test case1', (done) => {
	assert.deepEqual(null,results('invalid value'));
		done();
    });
        it('negative test case2', (done) => {
    assert.notDeepEqual([
    { name: 'kiran', percentage: 76.5 }]);
    done();
	});
});
