import { Component, OnInit } from '@angular/core';

import {Route, Router, NavigationExtras, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute)
   { }

  public dept =[
    {"id":1},
    {"id":2},
  ];


  goToCat()
  {
                       // register/category
    this.router.navigate([{},'category',this.dept[0].id],{relativeTo:this.route});//with routing parameter(navigating)
   // this.router.navigate(['/category'],{queryParams :{page:1,order:'newest'}});// with optional parameter
  }

 /* goToDept()
  {
                       // register/category
    this.router.navigate([{},'dept'],{relativeTo:this.route});
  }*/


  ngOnInit(): void {
  }

}
