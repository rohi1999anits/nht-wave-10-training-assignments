import React from 'react';
import Dashboard from './Components/dashboard/Dashboard';
import './App.css';
import Footer from './Components/footer/Footer';
import Header from './Components/header/Header';

import {BrowserRouter as Router,Switch, Route} from "react-router-dom"

class App extends React.Component{
  render(){
    return (
    <Router>
      <Header/>
      <Switch>
        <Route exact path="/" component={Dashboard} />
     </Switch>
     <Footer/>
    </Router>
  
    )
   
  }
}
export default App;
