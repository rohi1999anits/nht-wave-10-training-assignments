import axios from 'axios';
import React,{useState,useEffect} from 'react';
import Card from '../card/Card';
export default function Dashboard() {

const[trending,setTrending] =useState([]);
const[readlaterdb,setReadlaterdb] =useState([]);

    useEffect(() => {
        axios.get("https://newsapi.org/v2/top-headlines?country=in&apikey=11b66a09666449c1bb00ef7d62c8bda8&page=2")
        .then((res)=>{
          console.log(res.data.articles);
            setTrending(res.data.articles);
        })
    }, []);

    const readLater = (newCard) => {
        axios
          .post('http://localhost:3001/readlater', newCard, {
            headers: { 'Content-Type': 'application/json' },
          })
          .then(function (response) {
            if (response.status === 201) {
              setReadlaterdb([...readlaterdb, response.data]);
            }
          })
          .catch(function (error) {
            console.log(error);
          });
      };
    return (
        <div className='container'>
        <div className='row' style={{width:"max"}}>
                    {trending.map((news) => (
                        <Card
                        urlToImage={news.urlToImage}
                        title={news.title}
                        author={news.author}
                        readLater={readLater}
                        description={news.description}
                        url={news.url}
                        />
                    ))
                    } 
        </div>
        </div>
    );
};
