import React from 'react';

export default function Footer(){
    //&copy for copy right symbol--for the reserved characters we use '&'
    return <h6 className="footer" >copyright &copy; News React App</h6>
};
