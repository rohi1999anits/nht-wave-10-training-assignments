import Dashboard from '../Components/dashboard/Dashboard';
// please add your test cases here
describe('Testing sum', () => {


    it('should equal 3',()=>{
       expect(1+2).toBe(3);
      })

});
export default Dashboard;