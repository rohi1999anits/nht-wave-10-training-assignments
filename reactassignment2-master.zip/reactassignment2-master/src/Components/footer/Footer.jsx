import React from 'react';

export default function Footer(){
    return <h6 className="footer" >copyright &copy; React App</h6>
};
