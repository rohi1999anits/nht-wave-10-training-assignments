
import Header from '../Components/header/Header';
describe('Testing sum', () => {
    it('should equal 2',()=>{
       expect(1+1).toBe(2);
      })

});
export default Header;